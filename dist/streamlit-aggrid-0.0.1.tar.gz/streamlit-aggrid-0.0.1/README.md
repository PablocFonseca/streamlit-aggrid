# streamlit-aggrid

This is just a proof of concept. Links below:

* [Open in Streamlit Share](https://share.streamlit.io/pablocfonseca/streamlit-aggrid/main/example.py])

* [GitHub](https://github.com/PablocFonseca/streamlit-aggrid])

* [pypi.org](https://test.pypi.org/project/streamlit-aggrid-pkg-pablofonseca/0.0.1/])

just a proof of concept. AgGrid is an awsome grid for web. More information in [https://www.ag-grid.com/](https://www.ag-grid.com/)

# Install
```
pip install -i https://test.pypi.org/simple/streamlit-aggrid-pkg-pablofonseca

```
clone and streamlit run example.py